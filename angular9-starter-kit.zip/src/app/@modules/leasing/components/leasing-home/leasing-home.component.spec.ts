import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeasingHomeComponent } from './leasing-home.component';

describe('LeasingHomeComponent', () => {
  let component: LeasingHomeComponent;
  let fixture: ComponentFixture<LeasingHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LeasingHomeComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeasingHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
