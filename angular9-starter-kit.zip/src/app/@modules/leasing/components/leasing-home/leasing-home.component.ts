import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { SelectMap } from '@shared/models/select-map';
import { PropertiesService } from '@core/services/local/properties.service';

const ELEMENT_DATA = [{ type: 'سپرده نقدی', percent: '100' }];

@Component({
  selector: 'app-leasing-home',
  templateUrl: './leasing-home.component.html',
  styleUrls: ['./leasing-home.component.scss'],
})
export class LeasingHomeComponent implements OnInit {
  leasingForm: FormGroup;

  minInterestRate: any;
  maxInterestRate: any;

  componentTitle = 'leasing';

  facilityTypeList: SelectMap[] = [
    { value: '01', viewValue: 'فروش اقساطی کارکنان' },
    { value: '02', viewValue: 'فروش اقساطی کارکنان 2' },
  ];
  locationFromList: SelectMap[] = [{ value: '01', viewValue: 'عادی' }];
  locationTypeList: SelectMap[] = [{ value: '01', viewValue: 'منطقه عادی' }];
  usePlaceList: SelectMap[] = [{ value: '01', viewValue: 'ازنا' }];
  facilityPurposeList: SelectMap[] = [{ value: '01', viewValue: 'کشاورزی' }];
  sectorEconomicList: SelectMap[] = [{ value: '01', viewValue: 'ایجاد' }];
  sectorEconomicPrimaryList: SelectMap[] = [{ value: '01', viewValue: 'شیلات' }];
  sectorEconomicSubList: SelectMap[] = [{ value: '01', viewValue: 'صید آبزیان' }];
  ownershipList: SelectMap[] = [{ value: '01', viewValue: 'خصوصی' }];

  displayedColumns: string[] = ['type', 'percent'];
  dataSource = ELEMENT_DATA;

  constructor(private ps: PropertiesService, private http: HttpClient) {
    this.minInterestRate = ps.data.minInterestRate;
    this.maxInterestRate = ps.data.maxInterestRate;

    /*
    this.http.get('pages').subscribe((resp) => {
      console.log(resp);
    });
*/

    this.leasingForm = new FormGroup({
      customerName: new FormControl(null),
      customerNumber: new FormControl(null),
      requestDate: new FormControl(null),
      requestNumber: new FormControl(null),
      proposalNumber: new FormControl(null),
      contractType: new FormControl(null),
      facilityType: new FormControl(null),
      locationFrom: new FormControl(null),
      locationType: new FormControl(null),
      usePlace: new FormControl(null),
      facilityPurpose: new FormControl(null),
      sectorEconomic: new FormControl(null),
      sectorEconomicPrimary: new FormControl(null),
      sectorEconomicSub: new FormControl(null),

      netAmountOfFacility: new FormControl(null, [Validators.required]),
      facilityAmount: new FormControl(null),
      interestRate: new FormControl(null),

      amountCash: new FormControl(null),
      percentageCash: new FormControl(null),

      amountNonCash: new FormControl(null),
      percentageNonCash: new FormControl(null),

      penaltyRates: new FormControl(null),

      installmentsNumber: new FormControl(null, [Validators.required]),
      eachInstallmentDistance: new FormControl(null, [Validators.required]),

      howUse: new FormControl(null),
      howSplit: new FormControl(null),

      growthRate: new FormControl(null),
      step: new FormControl(null),

      deliveryTime: new FormControl(null),
      repaymentOfProfitsOnDeliveryOfGoods: new FormControl(null),

      breathingAway: new FormControl(null),
      breathingPeriodRepayment: new FormControl(null),

      grantFacilities: new FormControl(null),
      durationOfGrantingPeriod: new FormControl(null),
      repaymentOfBenefitOfFacility: new FormControl(null),

      facilityDuration: new FormControl(null),
      numberStamps: new FormControl(null),

      ownership: new FormControl(null),
      estateInsurance: new FormControl(null),

      details: new FormControl(null),
    });
  }

  submit() {}

  reset() {
    this.leasingForm.reset();
  }

  ngOnInit(): void {}
}
