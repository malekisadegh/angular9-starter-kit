import { GlobalErrorHandler } from './global-error-handler';
import { Injector } from '@angular/core';

describe('GlobalErrorHandler', () => {
  it('should create an instance', () => {
    expect();
  });
});
