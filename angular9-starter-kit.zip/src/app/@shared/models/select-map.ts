export interface SelectMap {
  value: string;
  viewValue: string;
}
