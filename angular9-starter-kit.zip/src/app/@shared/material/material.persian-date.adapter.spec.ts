import { MaterialPersianDateAdapter } from './material.persian-date.adapter';

describe('Material.PersianDate.Adapter', () => {
  it('should create an instance', () => {
    expect(new MaterialPersianDateAdapter()).toBeTruthy();
  });
});
