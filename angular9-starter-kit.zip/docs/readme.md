#BMI loan system
Welcome to the project documentation!

Use `npm run docs` for easier navigation.

Use `npm run start` to start development.

Use `json-server --watch server/db.json --port 3004` to run mock server.

or

Use `json-server --host 192.168.52.92 --watch server/db.json --port 3004` to run mock server.

Use `npm run build` for build production version of app.

Use `lite-server --baseDir="dist"` in project root too see production version.

## Available documentation

[[index]]
